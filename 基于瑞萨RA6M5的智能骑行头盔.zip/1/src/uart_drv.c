#include "uart_drv.h"
#include "hal_data.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stddef.h>

#define UART3_RX_BUFFER_SIZE  256
#define UART4_RX_BUFFER_SIZE  256
#define UART5_RX_BUFFER_SIZE  256
#define UART7_RX_BUFFER_SIZE  256

static volatile uint8_t uart3_rx_buf[UART3_RX_BUFFER_SIZE];
static volatile uint16_t uart3_rx_head = 0;
static volatile uint16_t uart3_rx_tail = 0;
static uart_callback_args_t uart3_callback_memory;

static volatile uint8_t uart4_rx_buf[UART4_RX_BUFFER_SIZE];
static volatile uint16_t uart4_rx_head = 0;
static volatile uint16_t uart4_rx_tail = 0;
static uart_callback_args_t uart4_callback_memory;

static volatile uint8_t uart5_rx_buf[UART5_RX_BUFFER_SIZE];
static volatile uint16_t uart5_rx_head = 0;
static volatile uint16_t uart5_rx_tail = 0;
static uart_callback_args_t uart5_callback_memory;

static volatile uint8_t uart7_rx_buf[UART7_RX_BUFFER_SIZE];
static volatile uint16_t uart7_rx_head = 0;
static volatile uint16_t uart7_rx_tail = 0;
static volatile uint8_t uart7_tx_done = 0;
static uart_callback_args_t uart7_callback_memory;

static void uart3_callback(uart_callback_args_t *p_args)
{
    if (UART_EVENT_RX_CHAR == p_args->event)
    {
        uint8_t data = (uint8_t)p_args->data;
        uint16_t next = (uart3_rx_head + 1) % UART3_RX_BUFFER_SIZE;
        if (next != uart3_rx_tail)
        {
            uart3_rx_buf[uart3_rx_head] = data;
            uart3_rx_head = next;
        }
    }
}

void uart4callback(uart_callback_args_t *p_args)
{
    if (UART_EVENT_RX_CHAR == p_args->event)
    {
        uint8_t data = (uint8_t)p_args->data;
        uint16_t next = (uart4_rx_head + 1) % UART4_RX_BUFFER_SIZE;
        if (next != uart4_rx_tail)
        {
            uart4_rx_buf[uart4_rx_head] = data;
            uart4_rx_head = next;
        }
    }
}

static void uart5_callback(uart_callback_args_t *p_args)
{
    if (UART_EVENT_RX_CHAR == p_args->event)
    {
        uint8_t data = (uint8_t)p_args->data;
        uint16_t next = (uart5_rx_head + 1) % UART5_RX_BUFFER_SIZE;
        if (next != uart5_rx_tail)
        {
            uart5_rx_buf[uart5_rx_head] = data;
            uart5_rx_head = next;
        }
    }
}

static void uart7_callback(uart_callback_args_t *p_args)
{
    if (UART_EVENT_RX_CHAR == p_args->event)
    {
        uint8_t data = (uint8_t)p_args->data;
        uint16_t next = (uart7_rx_head + 1) % UART7_RX_BUFFER_SIZE;
        if (next != uart7_rx_tail)
        {
            uart7_rx_buf[uart7_rx_head] = data;
            uart7_rx_head = next;
        }
    }
    else if (UART_EVENT_TX_COMPLETE == p_args->event)
    {
        uart7_tx_done = 1;
    }
}

void uart3_init(void)
{
    uart3_rx_head = 0;
    uart3_rx_tail = 0;
    
    g_uart3.p_api->open(g_uart3.p_ctrl, g_uart3.p_cfg);
    g_uart3.p_api->callbackSet(g_uart3.p_ctrl, uart3_callback, NULL, &uart3_callback_memory);
}

void uart3_send_data(uint8_t *data, uint16_t len)
{
    if (data == NULL || len == 0) return;
    g_uart3.p_api->write(g_uart3.p_ctrl, data, len);
}

uint16_t uart3_read_data(uint8_t *buf, uint16_t max_len)
{
    uint16_t count = 0;
    while (uart3_rx_tail != uart3_rx_head && count < max_len)
    {
        buf[count++] = uart3_rx_buf[uart3_rx_tail];
        uart3_rx_tail = (uart3_rx_tail + 1) % UART3_RX_BUFFER_SIZE;
    }
    return count;
}

void uart3_clear_rx_buffer(void)
{
    uart3_rx_head = 0;
    uart3_rx_tail = 0;
}

void uart4_init(void)
{
    uart4_rx_head = 0;
    uart4_rx_tail = 0;
    
    g_uart4.p_api->open(g_uart4.p_ctrl, g_uart4.p_cfg);
}

void uart4_send_string(const char *str)
{
    g_uart4.p_api->write(g_uart4.p_ctrl, (uint8_t *)str, strlen(str));
    for (volatile uint32_t i = 0; i < 50000; i++);
}

void uart4_send_data(uint8_t *data, uint16_t len)
{
    if (data == NULL || len == 0) return;
    g_uart4.p_api->write(g_uart4.p_ctrl, data, len);
    for (volatile uint32_t i = 0; i < len * 50000; i++);
}

uint16_t uart4_read_data(uint8_t *buf, uint16_t max_len)
{
    uint16_t count = 0;
    while (uart4_rx_tail != uart4_rx_head && count < max_len)
    {
        buf[count++] = uart4_rx_buf[uart4_rx_tail];
        uart4_rx_tail = (uart4_rx_tail + 1) % UART4_RX_BUFFER_SIZE;
    }
    return count;
}

void uart4_clear_rx_buffer(void)
{
    uart4_rx_head = 0;
    uart4_rx_tail = 0;
}

void uart5_init(void)
{
    uart5_rx_head = 0;
    uart5_rx_tail = 0;
    
    g_uart5.p_api->open(g_uart5.p_ctrl, g_uart5.p_cfg);
    g_uart5.p_api->callbackSet(g_uart5.p_ctrl, uart5_callback, NULL, &uart5_callback_memory);
}

void uart5_send_data(uint8_t *data, uint16_t len)
{
    if (data == NULL || len == 0) return;
    g_uart5.p_api->write(g_uart5.p_ctrl, data, len);
    for (volatile uint32_t i = 0; i < len * 10000; i++);
}

uint16_t uart5_read_data(uint8_t *buf, uint16_t max_len)
{
    uint16_t count = 0;
    while (uart5_rx_tail != uart5_rx_head && count < max_len)
    {
        buf[count++] = uart5_rx_buf[uart5_rx_tail];
        uart5_rx_tail = (uart5_rx_tail + 1) % UART5_RX_BUFFER_SIZE;
    }
    return count;
}

void uart5_clear_rx_buffer(void)
{
    uart5_rx_head = 0;
    uart5_rx_tail = 0;
}

void uart7_init(void)
{
    uart7_rx_head = 0;
    uart7_rx_tail = 0;

    g_uart7.p_api->open(g_uart7.p_ctrl, g_uart7.p_cfg);
    g_uart7.p_api->callbackSet(g_uart7.p_ctrl, uart7_callback, NULL, &uart7_callback_memory);
}

uint16_t uart7_read_data(uint8_t *buf, uint16_t max_len)
{
    uint16_t count = 0;
    while (uart7_rx_tail != uart7_rx_head && count < max_len)
    {
        buf[count++] = uart7_rx_buf[uart7_rx_tail];
        uart7_rx_tail = (uart7_rx_tail + 1) % UART7_RX_BUFFER_SIZE;
    }
    return count;
}

void uart7_clear_rx_buffer(void)
{
    uart7_rx_head = 0;
    uart7_rx_tail = 0;
}

void uart7_send_data(uint8_t *data, uint16_t len)
{
    if (data == NULL || len == 0) return;
    g_uart7.p_api->write(g_uart7.p_ctrl, data, len);
    for (volatile uint32_t i = 0; i < len * 50000; i++);
}

void uart7_send_string(const char *str)
{
    uint16_t len = (uint16_t)strlen(str);
    if (len == 0) return;
    g_uart7.p_api->write(g_uart7.p_ctrl, (uint8_t *)str, len);
    for (volatile uint32_t i = 0; i < len * 50000; i++);
}

void uart7_printf(const char *fmt, ...)
{
    static char buffer[256];  
    va_list args;
    va_start(args, fmt);
    vsprintf(buffer, fmt, args);
    va_end(args);
    uart7_send_string(buffer);
}

void uart3_send_string(const char *str)
{
    g_uart3.p_api->write(g_uart3.p_ctrl, (uint8_t *)str, strlen(str));
    for (volatile uint32_t i = 0; i < 50000; i++);
}

void uart3_send_data_wait(uint8_t *data, uint16_t len)
{
    if (data == NULL || len == 0) return;
    g_uart3.p_api->write(g_uart3.p_ctrl, data, len);
    for (volatile uint32_t i = 0; i < len * 50000; i++);
}

int fputc(int ch, FILE *f)
{
    static char buf[256];
    static int idx = 0;

   
    buf[idx++] = (char)ch;

    
    if (ch == '\n' || idx >= 255)
    {
        buf[idx] = '\0';
        uart7_send_string(buf);
        idx = 0;
    }

    return ch;
}
