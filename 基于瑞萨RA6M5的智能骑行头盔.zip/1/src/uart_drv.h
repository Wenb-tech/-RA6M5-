#ifndef UART_DRV_H
#define UART_DRV_H

#include <stdint.h>

void uart3_init(void);
void uart3_send_data(uint8_t *data, uint16_t len);
void uart3_send_data_wait(uint8_t *data, uint16_t len);
void uart3_send_string(const char *str);
uint16_t uart3_read_data(uint8_t *buf, uint16_t max_len);
void uart3_clear_rx_buffer(void);

void uart4_init(void);
void uart4_send_string(const char *str);
void uart4_send_data(uint8_t *data, uint16_t len);
uint16_t uart4_read_data(uint8_t *buf, uint16_t max_len);
void uart4_clear_rx_buffer(void);

void uart5_init(void);
void uart5_send_data(uint8_t *data, uint16_t len);
uint16_t uart5_read_data(uint8_t *buf, uint16_t max_len);
void uart5_clear_rx_buffer(void);

void uart7_init(void);
void uart7_send_data(uint8_t *data, uint16_t len);
void uart7_send_string(const char *str);
uint16_t uart7_read_data(uint8_t *buf, uint16_t max_len);
void uart7_clear_rx_buffer(void);
void uart7_printf(const char *fmt, ...);

#endif
