#include "dht11.h"
#include "hal_data.h"


static void dht11_delay_us(uint32_t us)
{
    R_BSP_SoftwareDelay(us, BSP_DELAY_UNITS_MICROSECONDS);
}

static void dht11_delay_ms(uint32_t ms)
{
    R_BSP_SoftwareDelay(ms, BSP_DELAY_UNITS_MILLISECONDS);
}


static void dht11_pin_output(void)
{
    R_BSP_PinAccessEnable();
    R_BSP_PinCfg(DHT11_PIN, IOPORT_CFG_PORT_DIRECTION_OUTPUT | IOPORT_CFG_DRIVE_HIGH);
    R_BSP_PinAccessDisable();
}


static void dht11_pin_input(void)
{
    R_BSP_PinAccessEnable();
    R_BSP_PinCfg(DHT11_PIN, IOPORT_CFG_PORT_DIRECTION_INPUT | IOPORT_CFG_PULLUP_ENABLE);
    R_BSP_PinAccessDisable();
}


static uint8_t dht11_pin_read(void)
{
    return (R_BSP_PinRead(DHT11_PIN) == BSP_IO_LEVEL_HIGH) ? 1 : 0;
}


static void dht11_pin_write(uint8_t high)
{
    R_BSP_PinAccessEnable();
    R_BSP_PinWrite(DHT11_PIN, high ? BSP_IO_LEVEL_HIGH : BSP_IO_LEVEL_LOW);
    R_BSP_PinAccessDisable();
}

void dht11_init(void)
{
    dht11_pin_output();
    dht11_pin_write(1);
    dht11_delay_ms(100);
}

int dht11_read(DHT11_Data *data)
{
    uint8_t buf[5] = {0, 0, 0, 0, 0};
    uint8_t i, j;
    uint32_t timeout;

   
    __disable_irq();

    
    dht11_pin_output();
    dht11_pin_write(0);
    dht11_delay_ms(20);

    
    dht11_pin_write(1);
    dht11_delay_us(30);
    dht11_pin_input();

   
    timeout = 0;
    while (dht11_pin_read()) {
        dht11_delay_us(1);
        if (++timeout > 100) {
            __enable_irq();
            return -1;
        }
    }

   
    timeout = 0;
    while (!dht11_pin_read()) {
        dht11_delay_us(1);
        if (++timeout > 100) {
            __enable_irq();
            return -1;
        }
    }

    
    timeout = 0;
    while (dht11_pin_read()) {
        dht11_delay_us(1);
        if (++timeout > 100) {
            __enable_irq();
            return -1;
        }
    }

    
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            
            timeout = 0;
            while (!dht11_pin_read()) {
                dht11_delay_us(1);
                if (++timeout > 100) {
                    __enable_irq();
                    return -1;
                }
            }

            
            dht11_delay_us(40);

            buf[i] <<= 1;
            if (dht11_pin_read()) {
                buf[i] |= 1;
                
                timeout = 0;
                while (dht11_pin_read()) {
                    dht11_delay_us(1);
                    if (++timeout > 100) break;
                }
            }
        }
    }

    
    __enable_irq();

    
    dht11_delay_us(50);

    
    uint8_t sum = buf[0] + buf[1] + buf[2] + buf[3];
    if (sum != buf[4]) {
        data->is_valid = 0;
        return -1;
    }

    data->humidity_int = buf[0];
    data->humidity_dec = buf[1];
    data->temp_int = buf[2];
    data->temp_dec = buf[3];
    data->checksum = buf[4];
    data->is_valid = 1;

    
    dht11_pin_output();
    dht11_pin_write(1);

    return 0;
}
