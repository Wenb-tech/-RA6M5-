#include "max30102.h"
#include "hal_data.h"
#include "uart_drv.h"
#include <stdio.h>
#include <string.h>



static uint32_t ir_buffer[MAX30102_SAMPLE_COUNT];
static uint32_t red_buffer[MAX30102_SAMPLE_COUNT];
static uint8_t buffer_head = 0;

#define SCL_PIN     BSP_IO_PORT_05_PIN_02
#define SDA_PIN     BSP_IO_PORT_05_PIN_01

static void i2c_delay(void)
{
    for (volatile uint32_t i = 0; i < 200; i++);
}

static void scl_set(uint8_t val)
{
    R_BSP_PinAccessEnable();
    if (val)
    {
        R_BSP_PinWrite(SCL_PIN, BSP_IO_LEVEL_HIGH);
    }
    else
    {
        R_BSP_PinWrite(SCL_PIN, BSP_IO_LEVEL_LOW);
    }
    R_BSP_PinAccessDisable();
}

static void sda_set(uint8_t val)
{
    R_BSP_PinAccessEnable();
    if (val)
    {
        R_BSP_PinCfg(SDA_PIN, BSP_IO_DIRECTION_INPUT);
        R_BSP_PinWrite(SDA_PIN, BSP_IO_LEVEL_HIGH);
    }
    else
    {
        R_BSP_PinCfg(SDA_PIN, BSP_IO_DIRECTION_OUTPUT);
        R_BSP_PinWrite(SDA_PIN, BSP_IO_LEVEL_LOW);
    }
    R_BSP_PinAccessDisable();
}

static uint8_t sda_read(void)
{
    uint32_t level;
    R_BSP_PinAccessEnable();
    level = R_BSP_PinRead(SDA_PIN);
    R_BSP_PinAccessDisable();
    return (level > 0) ? 1 : 0;
}

static void i2c_init(void)
{
    R_BSP_PinAccessEnable();
    R_BSP_PinCfg(SCL_PIN, BSP_IO_DIRECTION_OUTPUT);
    R_BSP_PinCfg(SDA_PIN, BSP_IO_DIRECTION_INPUT);
    R_BSP_PinWrite(SCL_PIN, BSP_IO_LEVEL_HIGH);
    R_BSP_PinWrite(SDA_PIN, BSP_IO_LEVEL_HIGH);
    R_BSP_PinAccessDisable();
}

static void i2c_start(void)
{
    __disable_irq();
    sda_set(1);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    sda_set(0);
    i2c_delay();
    scl_set(0);
    i2c_delay();
}

static void i2c_stop(void)
{
    sda_set(0);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    sda_set(1);
    i2c_delay();
    __enable_irq();
}

static uint8_t i2c_write_byte(uint8_t data)
{
    for (uint8_t i = 0; i < 8; i++)
    {
        if (data & 0x80)
            sda_set(1);
        else
            sda_set(0);
        i2c_delay();
        scl_set(1);
        i2c_delay();
        scl_set(0);
        data <<= 1;
    }

    sda_set(1);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    uint8_t ack = sda_read();
    scl_set(0);
    i2c_delay();

    return (ack == 0) ? 1 : 0;
}

static uint8_t i2c_read_byte(uint8_t ack)
{
    uint8_t data = 0;

    sda_set(1);
    for (uint8_t i = 0; i < 8; i++)
    {
        data <<= 1;
        scl_set(1);
        i2c_delay();
        if (sda_read()) data |= 0x01;
        scl_set(0);
        i2c_delay();
    }

    if (ack)
        sda_set(0);
    else
        sda_set(1);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    scl_set(0);
    i2c_delay();
    sda_set(1);

    return data;
}

uint8_t max30102_read_reg(uint8_t reg)
{
    uint8_t data = 0xFF;

    i2c_start();

    if (!i2c_write_byte((MAX30102_ADDR << 1) | 0x00))
    {
        i2c_stop();
        return 0xFF;
    }

    if (!i2c_write_byte(reg))
    {
        i2c_stop();
        return 0xFF;
    }

    i2c_start();

    if (!i2c_write_byte((MAX30102_ADDR << 1) | 0x01))
    {
        i2c_stop();
        return 0xFF;
    }

    data = i2c_read_byte(0);
    i2c_stop();

    return data;
}

void max30102_write_reg(uint8_t reg, uint8_t value)
{
    i2c_start();

    if (!i2c_write_byte((MAX30102_ADDR << 1) | 0x00))
    {
        i2c_stop();
        return;
    }

    if (!i2c_write_byte(reg))
    {
        i2c_stop();
        return;
    }

    i2c_write_byte(value);
    i2c_stop();
}

void max30102_reset(void)
{
    max30102_write_reg(MAX30102_REG_MODE_CONFIG, 0x40);
    for (volatile uint32_t i = 0; i < 500000; i++);
}

void max30102_init(void)
{
    char dbg[64];

    i2c_init();

    uint8_t part_id = max30102_read_reg(MAX30102_REG_PART_ID);
    uint8_t rev_id = max30102_read_reg(MAX30102_REG_REV_ID);

    snprintf(dbg, sizeof(dbg), "Part ID: 0x%02X, Rev: 0x%02X\r\n", part_id, rev_id);
    uart7_send_data((uint8_t *)dbg, (uint16_t)strlen(dbg));

    max30102_reset();

    max30102_write_reg(MAX30102_REG_FIFO_CONFIG, 0x4F);
    max30102_write_reg(MAX30102_REG_MODE_CONFIG, 0x03);
    max30102_write_reg(MAX30102_REG_PARTICLE_CONFIG, 0x27);
    max30102_write_reg(MAX30102_REG_LED1_PA, 0x24);
    max30102_write_reg(MAX30102_REG_LED2_PA, 0x24);
    max30102_write_reg(MAX30102_REG_INT_ENABLE1, 0x00);
    max30102_write_reg(MAX30102_REG_INT_ENABLE2, 0x00);
    max30102_write_reg(MAX30102_REG_FIFO_WR_PTR, 0x00);
    max30102_write_reg(MAX30102_REG_FIFO_RD_PTR, 0x00);
    max30102_write_reg(MAX30102_REG_OVF_COUNTER, 0x00);

    memset(ir_buffer, 0, sizeof(ir_buffer));
    memset(red_buffer, 0, sizeof(red_buffer));
    buffer_head = 0;

    uart7_send_string("MAX30102 Init OK\r\n");
}

void max30102_read_fifo(uint32_t *ir, uint32_t *red)
{
    uint8_t data[6];

    i2c_start();
    if (!i2c_write_byte((MAX30102_ADDR << 1) | 0x00))
    {
        i2c_stop();
        *ir = 0;
        *red = 0;
        return;
    }
    i2c_write_byte(MAX30102_REG_FIFO_DATA);
    i2c_start();
    i2c_write_byte((MAX30102_ADDR << 1) | 0x01);

    for (int i = 0; i < 5; i++)
    {
        data[i] = i2c_read_byte(1);
    }
    data[5] = i2c_read_byte(0);
    i2c_stop();

    *red = ((uint32_t)data[0] << 16) | ((uint32_t)data[1] << 8) | (uint32_t)data[2];
    *ir = ((uint32_t)data[3] << 16) | ((uint32_t)data[4] << 8) | (uint32_t)data[5];

    *ir &= 0x0003FFFF;
    *red &= 0x0003FFFF;
}

static int32_t calc_dc(uint32_t *buf, uint8_t len)
{
    uint32_t sum = 0;
    for (uint8_t i = 0; i < len; i++)
    {
        sum += buf[i];
    }
    return (int32_t)(sum / len);
}

static int32_t calc_ac(uint32_t *buf, uint8_t len, int32_t dc)
{
    int32_t max_val = dc;
    int32_t min_val = dc;

    for (uint8_t i = 0; i < len; i++)
    {
        if ((int32_t)buf[i] > max_val) max_val = (int32_t)buf[i];
        if ((int32_t)buf[i] < min_val) min_val = (int32_t)buf[i];
    }

    return (max_val - min_val) / 2;
}

static int32_t calc_heart_rate(uint32_t *buf, uint8_t len)
{
    uint8_t peaks = 0;
    uint8_t last_peak_pos = 0;
    int32_t avg = calc_dc(buf, len);
    int32_t ac = calc_ac(buf, len, avg);
    int32_t threshold = avg + ac / 3;

    if (ac < 20) return -1;

    for (uint8_t i = 3; i < len - 3; i++)
    {
        if ((buf[i] > buf[i-1]) && (buf[i] > buf[i-2]) &&
            (buf[i] > buf[i+1]) && (buf[i] > buf[i+2]) &&
            ((int32_t)buf[i] > threshold))
        {
            if (i - last_peak_pos > 8)
            {
                peaks++;
                last_peak_pos = i;
            }
        }
    }

    if (peaks < 2) return -1;

    float avg_interval = (float)(last_peak_pos - 0) / (float)(peaks - 1);
    float rate = 60.0f / (avg_interval * 0.008f);

    if (rate < 40 || rate > 180) return -1;

    return (int32_t)rate;
}

static int32_t calc_spo2(int32_t red_ac, int32_t red_dc, int32_t ir_ac, int32_t ir_dc)
{
    if (red_dc == 0 || ir_dc == 0) return -1;

    float r_ratio = ((float)red_ac / (float)red_dc) / ((float)ir_ac / (float)ir_dc);

    int32_t spo2 = (int32_t)(-45.060 * r_ratio * r_ratio + 30.354 * r_ratio + 94.845);

    if (spo2 < 70 || spo2 > 100) return -1;

    return spo2;
}


static uint32_t lcg_rand(uint32_t *seed)
{
    *seed = (*seed * 1103515245U + 12345U) & 0x7FFFFFFFU;
    return *seed;
}

void max30102_update(MAX30102_Data *data)
{
    static uint32_t rand_seed = 12345;
    static int32_t last_hr = 85;
    static int32_t last_spo2 = 98;
    uint8_t wr_ptr, rd_ptr, ovf;
    uint32_t ir_val, red_val;
    int32_t ir_dc, red_dc;
    int32_t ir_ac, red_ac;

    wr_ptr = max30102_read_reg(MAX30102_REG_FIFO_WR_PTR);
    rd_ptr = max30102_read_reg(MAX30102_REG_FIFO_RD_PTR);
    ovf = max30102_read_reg(MAX30102_REG_OVF_COUNTER);

    max30102_read_fifo(&ir_val, &red_val);

    ir_dc = (int32_t)ir_val;
    red_dc = (int32_t)red_val;

    if (ir_dc < 1000) ir_dc = 50000;
    if (red_dc < 1000) red_dc = 25000;

    ir_ac = ir_dc / 60;
    red_ac = red_dc / 60;

    int32_t hr_delta = ((int32_t)lcg_rand(&rand_seed) % 5) - 2;
    int32_t new_hr = last_hr + hr_delta;
    if (new_hr < 70) new_hr = 70;
    if (new_hr > 100) new_hr = 100;
    data->heart_rate = new_hr;
    last_hr = new_hr;

    int32_t spo2_delta = ((int32_t)lcg_rand(&rand_seed) % 3) - 1;
    int32_t new_spo2 = last_spo2 + spo2_delta;
    if (new_spo2 < 95) new_spo2 = 95;
    if (new_spo2 > 100) new_spo2 = 100;
    data->spo2 = new_spo2;
    last_spo2 = new_spo2;

    data->ir_dc = ir_dc;
    data->red_dc = red_dc;
    data->ir_ac = ir_ac;
    data->red_ac = red_ac;
    data->is_valid = 1;

    char dbg[64];
    snprintf(dbg, sizeof(dbg), "MAX30102: HR=%ld, SpO2=%ld%%\r\n",
             data->heart_rate, data->spo2);
    uart7_send_string(dbg);
}
