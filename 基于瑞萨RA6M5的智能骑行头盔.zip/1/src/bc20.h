#ifndef BC20_H
#define BC20_H

#include <stdint.h>

#define BC20_BUF_LEN    512

#define OneNet_PRODUCT_ID   "EfL468qlnN"
#define OneNet_DEVICE_ID    "TEST"
#define OneNet_TOKEN        "version=2018-10-31&res=products%2FEfL468qlnN%2Fdevices%2FTEST&et=1982803361&method=md5&sign=Q8ch0dU6aGmAb8STkGlEDw%3D%3D"
#define OneNet_SERVER       "mqtts.heclouds.com"

typedef enum {
    BC20_OK = 0,
    BC20_ERR_SEND = 1,
    BC20_ERR_RESPONSE = 2,
    BC20_ERR_TIMEOUT = 3,
    BC20_ERR_SIM = 4,
    BC20_ERR_NETWORK = 5,
    BC20_ERR_GPS = 6,
    BC20_ERR_OneNet = 7
} BC20_ErrorCode;

typedef struct {
    float latitude;
    float longitude;
    uint8_t is_valid;
} GPS_Data;

typedef struct {
    float temperature;
    float humidity;
    uint8_t is_valid;
} Sensor_Data;

typedef struct {
    float heart_rate;
    float spo2;
    uint8_t is_valid;
} HRSpO2_Data;

typedef struct {
    BC20_ErrorCode err_code;
    uint8_t is_connected;
    GPS_Data gps;
} BC20_Status;

extern BC20_Status s_bc20_status;

void BC20_Init(void);
void BC20_ClearRecvBuf(void);
BC20_ErrorCode BC20_InitGPS(void);
BC20_ErrorCode BC20_ConnectOneNet(void);
BC20_ErrorCode BC20_GetGPSData(GPS_Data *gps);
BC20_ErrorCode BC20_SendToOneNet(const GPS_Data *gps, float temp, float humi, const HRSpO2_Data *hr_spo2, const char *incident);
void BC20_ProcessReceivedData(void);

#endif
