#include "asrpro.h"
#include "uart_drv.h"
#include "hal_data.h"
#include <stdio.h>
#include <string.h>

ASRPRO_Status s_asr_status = {0};

#define ASR_BUFSIZE  32
static char s_asr_buf[ASR_BUFSIZE];
static uint8_t s_asr_len = 0;

void asrpro_init(void)
{
    uart4_init();
    uart4_clear_rx_buffer();
    s_asr_status.is_ready = 1;
    s_asr_status.last_cmd = ASR_CMD_NONE;
    uart7_printf("ASRPRO Init OK (UART4, 9600)\r\n");
}

void asrpro_process(void)
{
    uint8_t byte;
    if (!s_asr_status.is_ready) return;

    while (uart4_read_data(&byte, 1) > 0)
    {
        if (s_asr_len < ASR_BUFSIZE - 1)
        {
            s_asr_buf[s_asr_len++] = (char)byte;
            s_asr_buf[s_asr_len] = '\0';
        }

        if (byte == '\n' || s_asr_len >= 10)
        {
            if (s_asr_len >= 2)
            {
                if (s_asr_buf[0] == 'T')
                {
                    s_asr_status.last_cmd = ASR_CMD_TEMP;
                    uart7_printf("ASR: 温度查询\r\n");
                }
                else if (s_asr_buf[0] == 'H')
                {
                    s_asr_status.last_cmd = ASR_CMD_HUMI;
                    uart7_printf("ASR: 湿度查询\r\n");
                }
                else if (s_asr_buf[0] == 'B')
                {
                    s_asr_status.last_cmd = ASR_CMD_BOTH;
                    uart7_printf("ASR: 温湿度查询\r\n");
                }
                else if (s_asr_buf[0] == 'X')
                {
                    s_asr_status.last_cmd = ASR_CMD_HELLO;
                    uart7_printf("ASR: 你好\r\n");
                }
                else if (s_asr_buf[0] == 'S')
                {
                    s_asr_status.last_cmd = ASR_CMD_STOP_HELP;
                    uart7_printf("ASR: 停止求救\r\n");
                }
                else if (s_asr_buf[0] == 'O' && s_asr_buf[1] == 'N')
                {
                    s_asr_status.last_cmd = ASR_CMD_LED_ON;
                    uart7_printf("ASR: 开灯\r\n");
                }
                else if (s_asr_buf[0] == 'O' && s_asr_buf[1] == 'F')
                {
                    s_asr_status.last_cmd = ASR_CMD_LED_OFF;
                    uart7_printf("ASR: 关灯\r\n");
                }
                else if (s_asr_buf[0] == 'N' && s_asr_buf[1] == '\0')
                {
                    s_asr_status.last_cmd = ASR_CMD_NEED_HELP;
                    uart7_printf("ASR: 需要求救\r\n");
                }
                else if (s_asr_buf[0] == 'D')
                {
                    s_asr_status.last_cmd = ASR_CMD_NO_HELP;
                    uart7_printf("ASR: 不需要求救\r\n");
                }
            }
            s_asr_len = 0;
            memset(s_asr_buf, 0, ASR_BUFSIZE);
        }
    }
}

void asrpro_speak_temperature(float temp)
{
    char cmd[16];
    snprintf(cmd, sizeof(cmd), "T%d\r\n", (int)temp);
    uart4_send_data((uint8_t*)cmd, strlen(cmd));
    uart7_printf("ASR Send: %s", cmd);
}

void asrpro_speak_humidity(float humi)
{
    char cmd[16];
    snprintf(cmd, sizeof(cmd), "H%d\r\n", (int)humi);
    uart4_send_data((uint8_t*)cmd, strlen(cmd));
    uart7_printf("ASR Send: %s", cmd);
}

void asrpro_speak_both(float temp, float humi)
{
    char cmd[16];
    snprintf(cmd, sizeof(cmd), "B%d,%d\r\n", (int)temp, (int)humi);
    uart4_send_data((uint8_t*)cmd, strlen(cmd));
    uart7_printf("ASR Send: %s", cmd);
}

void asrpro_speak_hello(void)
{
    char cmd[] = "X\r\n";
    uart4_send_data((uint8_t*)cmd, strlen(cmd));
    uart7_printf("ASR Send: X\r\n");
}

void asrpro_speak_fall(void)
{
    char cmd[] = "F\r\n";
    uart4_send_data((uint8_t*)cmd, strlen(cmd));
    uart7_printf("ASR Send: F (Fall detected!)\r\n");
}