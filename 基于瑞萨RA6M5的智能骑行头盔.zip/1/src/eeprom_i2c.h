#ifndef EEPROM_I2C_H
#define EEPROM_I2C_H

#include <stdint.h>
#include <stdbool.h>

void eeprom_i2c_init(void);
bool eeprom_write_byte(uint8_t addr, uint8_t data);
bool eeprom_read_byte(uint8_t addr, uint8_t *data);
bool eeprom_write_bytes(uint8_t addr, uint8_t *data, uint16_t len);
bool eeprom_read_bytes(uint8_t addr, uint8_t *data, uint16_t len);
void eeprom_erase_page(uint8_t page_addr, uint8_t page_size);

#endif
