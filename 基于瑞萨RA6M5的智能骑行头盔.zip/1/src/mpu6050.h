#ifndef MPU6050_H
#define MPU6050_H

#include <stdint.h>

#define MPU6050_ADDR        0x68

#define MPU6050_REG_PWR_MGMT_1   0x6B
#define MPU6050_REG_SMPLRT_DIV   0x19
#define MPU6050_REG_CONFIG       0x1A
#define MPU6050_REG_ACCEL_CONFIG 0x1C
#define MPU6050_REG_ACCEL_XOUT_H 0x3B

typedef struct {
    int16_t ax;
    int16_t ay;
    int16_t az;
    float ax_g;
    float ay_g;
    float az_g;
    uint8_t is_valid;
} MPU6050_Data;

void mpu6050_init(void);
int mpu6050_read_accel(MPU6050_Data *data);

#endif