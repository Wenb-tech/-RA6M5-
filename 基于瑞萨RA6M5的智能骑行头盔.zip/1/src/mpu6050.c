#include "mpu6050.h"
#include "hal_data.h"
#include "uart_drv.h"
#include <stdio.h>

#define SCL_PIN     BSP_IO_PORT_04_PIN_15
#define SDA_PIN     BSP_IO_PORT_04_PIN_14

static void i2c_delay(void)
{
    for (volatile uint32_t i = 0; i < 500; i++);
}

static void scl_set(uint8_t val)
{
    R_BSP_PinAccessEnable();
    if (val)
    {
        R_BSP_PinWrite(SCL_PIN, BSP_IO_LEVEL_HIGH);
    }
    else
    {
        R_BSP_PinWrite(SCL_PIN, BSP_IO_LEVEL_LOW);
    }
    R_BSP_PinAccessDisable();
}

static void sda_set(uint8_t val)
{
    R_BSP_PinAccessEnable();
    if (val)
    {
        R_BSP_PinCfg(SDA_PIN, BSP_IO_DIRECTION_INPUT);
        R_BSP_PinWrite(SDA_PIN, BSP_IO_LEVEL_HIGH);
    }
    else
    {
        R_BSP_PinCfg(SDA_PIN, BSP_IO_DIRECTION_OUTPUT);
        R_BSP_PinWrite(SDA_PIN, BSP_IO_LEVEL_LOW);
    }
    R_BSP_PinAccessDisable();
}

static uint8_t sda_read(void)
{
    uint32_t level;
    R_BSP_PinAccessEnable();
    level = R_BSP_PinRead(SDA_PIN);
    R_BSP_PinAccessDisable();
    return (level > 0) ? 1 : 0;
}

static void i2c_init(void)
{
    R_BSP_PinAccessEnable();
    R_BSP_PinCfg(SCL_PIN, BSP_IO_DIRECTION_OUTPUT);
    R_BSP_PinCfg(SDA_PIN, BSP_IO_DIRECTION_INPUT);
    R_BSP_PinWrite(SCL_PIN, BSP_IO_LEVEL_HIGH);
    R_BSP_PinWrite(SDA_PIN, BSP_IO_LEVEL_HIGH);
    R_BSP_PinAccessDisable();
}

static void i2c_start(void)
{
    __disable_irq();
    sda_set(1);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    sda_set(0);
    i2c_delay();
    scl_set(0);
    i2c_delay();
}

static void i2c_stop(void)
{
    sda_set(0);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    sda_set(1);
    i2c_delay();
    __enable_irq();
}

static uint8_t i2c_write_byte(uint8_t data)
{
    uint8_t i, ack;
    for (i = 0; i < 8; i++)
    {
        sda_set((data >> 7) & 1);
        data <<= 1;
        i2c_delay();
        scl_set(1);
        i2c_delay();
        scl_set(0);
        i2c_delay();
    }
    sda_set(1);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    ack = sda_read();
    scl_set(0);
    i2c_delay();
    return ack;
}

static uint8_t i2c_read_byte(uint8_t ack)
{
    uint8_t i, data = 0;
    sda_set(1);
    for (i = 0; i < 8; i++)
    {
        i2c_delay();
        scl_set(1);
        i2c_delay();
        data = (data << 1) | sda_read();
        scl_set(0);
        i2c_delay();
    }
    sda_set(ack);
    i2c_delay();
    scl_set(1);
    i2c_delay();
    scl_set(0);
    i2c_delay();
    return data;
}

static uint8_t mpu6050_write_reg(uint8_t reg, uint8_t val)
{
    i2c_start();
    if (i2c_write_byte((MPU6050_ADDR << 1) | 0)) { i2c_stop(); return 1; }
    if (i2c_write_byte(reg)) { i2c_stop(); return 1; }
    if (i2c_write_byte(val)) { i2c_stop(); return 1; }
    i2c_stop();
    return 0;
}

static uint8_t mpu6050_read_reg(uint8_t reg)
{
    uint8_t val;
    i2c_start();
    if (i2c_write_byte((MPU6050_ADDR << 1) | 0)) { i2c_stop(); return 0; }
    if (i2c_write_byte(reg)) { i2c_stop(); return 0; }
    i2c_start();
    if (i2c_write_byte((MPU6050_ADDR << 1) | 1)) { i2c_stop(); return 0; }
    val = i2c_read_byte(0);
    i2c_stop();
    return val;
}

void mpu6050_init(void)
{
    i2c_init();
    R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS);

    mpu6050_write_reg(MPU6050_REG_PWR_MGMT_1, 0x00);
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);

    mpu6050_write_reg(MPU6050_REG_SMPLRT_DIV, 0x07);
    mpu6050_write_reg(MPU6050_REG_CONFIG, 0x00);
    mpu6050_write_reg(MPU6050_REG_ACCEL_CONFIG, 0x00);

    uint8_t who_am_i = mpu6050_read_reg(0x75);
    uart7_printf("MPU6050 WHO_AM_I: 0x%02X\r\n", who_am_i);
}

int mpu6050_read_accel(MPU6050_Data *data)
{
    uint8_t buf[2];
    int retry;

    if (data == NULL) return -1;

    for (retry = 0; retry < 3; retry++)
    {
        __disable_irq();
        i2c_start();
        if (i2c_write_byte((MPU6050_ADDR << 1) | 0)) { i2c_stop(); __enable_irq(); continue; }
        if (i2c_write_byte(MPU6050_REG_ACCEL_XOUT_H)) { i2c_stop(); __enable_irq(); continue; }
        i2c_start();
        if (i2c_write_byte((MPU6050_ADDR << 1) | 1)) { i2c_stop(); __enable_irq(); continue; }
        buf[0] = i2c_read_byte(1);
        buf[1] = i2c_read_byte(0);
        i2c_stop();
        __enable_irq();
        data->ax = (buf[0] << 8) | buf[1];
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);

        __disable_irq();
        i2c_start();
        if (i2c_write_byte((MPU6050_ADDR << 1) | 0)) { i2c_stop(); __enable_irq(); continue; }
        if (i2c_write_byte(MPU6050_REG_ACCEL_XOUT_H + 2)) { i2c_stop(); __enable_irq(); continue; }
        i2c_start();
        if (i2c_write_byte((MPU6050_ADDR << 1) | 1)) { i2c_stop(); __enable_irq(); continue; }
        buf[0] = i2c_read_byte(1);
        buf[1] = i2c_read_byte(0);
        i2c_stop();
        __enable_irq();
        data->ay = (buf[0] << 8) | buf[1];
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);

        __disable_irq();
        i2c_start();
        if (i2c_write_byte((MPU6050_ADDR << 1) | 0)) { i2c_stop(); __enable_irq(); continue; }
        if (i2c_write_byte(MPU6050_REG_ACCEL_XOUT_H + 4)) { i2c_stop(); __enable_irq(); continue; }
        i2c_start();
        if (i2c_write_byte((MPU6050_ADDR << 1) | 1)) { i2c_stop(); __enable_irq(); continue; }
        buf[0] = i2c_read_byte(1);
        buf[1] = i2c_read_byte(0);
        i2c_stop();
        __enable_irq();
        data->az = (buf[0] << 8) | buf[1];

        data->ax_g = (float)data->ax / 16384.0f;
        data->ay_g = (float)data->ay / 16384.0f;
        data->az_g = (float)data->az / 16384.0f;

        data->is_valid = 1;

        if (data->ax != 0xFFFF && data->ay != 0xFFFF && data->az != 0xFFFF)
        {
            return 0;
        }
    }

    return -1;
}