#ifndef DHT11_H
#define DHT11_H

#include <stdint.h>

/* P203 引脚 */
#define DHT11_PIN          BSP_IO_PORT_02_PIN_03

typedef struct {
    uint8_t humidity_int;     /* 湿度整数部分 */
    uint8_t humidity_dec;     /* 湿度小数部分 */
    uint8_t temp_int;         /* 温度整数部分 */
    uint8_t temp_dec;         /* 温度小数部分 */
    uint8_t checksum;         /* 校验和 */
    uint8_t is_valid;         /* 数据是否有效 */
} DHT11_Data;

/* 初始化 DHT11 */
void dht11_init(void);

/* 读取 DHT11 温湿度数据，成功返回0，失败返回-1 */
int dht11_read(DHT11_Data *data);

#endif /* DHT11_H */
