#include "bc20.h"
#include "uart_drv.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static char s_recv_buf[BC20_BUF_LEN];
static uint16_t s_recv_len = 0;
BC20_Status s_bc20_status = {0};

static BC20_ErrorCode BC20_SendAT(const char *cmd, const char *expected_resp, uint32_t timeout_ms);
static BC20_ErrorCode BC20_ParseGPRMC(const char *rmc_str, GPS_Data *gps);


static void delay_ms(uint32_t ms)
{
    for (volatile uint32_t i = 0; i < ms * 40000; i++);
}

void BC20_ClearRecvBuf(void)
{
    memset(s_recv_buf, 0, BC20_BUF_LEN);
    s_recv_len = 0;
    uart3_clear_rx_buffer();
    delay_ms(50);
}


static BC20_ErrorCode BC20_SendAT(const char *cmd, const char *expected_resp, uint32_t timeout_ms)
{
    uint32_t count = 0;
    uint32_t max_count = timeout_ms / 10;
    if (timeout_ms % 10 != 0) max_count++;

    BC20_ClearRecvBuf();

    uart7_printf("\r\n[CMD]: %s", cmd);
    uart3_send_data_wait((uint8_t *)cmd, (uint16_t)strlen(cmd));

    while (count < max_count)
    {
        
        uint8_t byte;
        uint16_t read_total = 0;
        while (uart3_read_data(&byte, 1) > 0 && read_total < 256)
        {
            read_total++;
            if (s_recv_len < BC20_BUF_LEN - 1)
            {
                s_recv_buf[s_recv_len++] = (char)byte;
                s_recv_buf[s_recv_len] = '\0';
            }
        }

        
        if (s_recv_len > 0)
        {
            if (expected_resp[0] == '\0')
            {
                
                uart7_printf("[RSP]: %s\r\n", s_recv_buf);
                return BC20_OK;
            }
            else if (strstr(s_recv_buf, expected_resp) != NULL)
            {
                uart7_printf("[RSP]: %s\r\n", s_recv_buf);
                return BC20_OK;
            }
        }

        delay_ms(10);
        count++;
    }

    uart7_printf("[TIMEOUT] expect: %s, got: %s\r\n", expected_resp, s_recv_buf);
    return BC20_ERR_TIMEOUT;
}


void BC20_Init(void)
{
    BC20_ErrorCode ret;
    BC20_ClearRecvBuf();

    uart7_printf("\r\n====================================\r\n");
    uart7_printf("BC20 Init Start\r\n");

    
    uart7_printf("Step1: Test AT...\r\n");
    ret = BC20_SendAT("AT\r\n", "OK", 3000);
    if (ret != BC20_OK)
    {
        uart7_printf("BC20 No Response!\r\n");
        s_bc20_status.err_code = BC20_ERR_RESPONSE;
        return;
    }

    
    uart7_printf("Step2: Disable Echo...\r\n");
    ret = BC20_SendAT("ATE0\r\n", "OK", 3000);
    if (ret != BC20_OK)
    {
        uart7_printf("ATE0 Failed!\r\n");
        s_bc20_status.err_code = BC20_ERR_RESPONSE;
        return;
    }

    
    uart7_printf("Step3: Check SIM...\r\n");
    ret = BC20_SendAT("AT+CIMI\r\n", "OK", 3000);
    if (ret != BC20_OK)
    {
        uart7_printf("SIM Error!\r\n");
        s_bc20_status.err_code = BC20_ERR_SIM;
        return;
    }
    BC20_ClearRecvBuf();

    
    uart7_printf("Step4: Wait Network...\r\n");
    ret = BC20_SendAT("AT+CGATT?\r\n", "+CGATT: 1", 15000);
    if (ret != BC20_OK)
    {
        uart7_printf("Network Failed!\r\n");
        s_bc20_status.err_code = BC20_ERR_NETWORK;
        return;
    }
    BC20_ClearRecvBuf();

    
    uart7_printf("Step5: Signal Quality...\r\n");
    ret = BC20_SendAT("AT+CSQ\r\n", "+CSQ", 3000);
    if (ret == BC20_OK)
    {
        uart7_printf("Signal: %s\r\n", s_recv_buf);
    }
    BC20_ClearRecvBuf();

    
    uart7_printf("Step6: Init GPS...\r\n");
    if (BC20_InitGPS() != BC20_OK)
    {
        uart7_printf("GPS Init Failed (not blocking)\r\n");
    }
    else
    {
        uart7_printf("GPS Init OK\r\n");
    }

    s_bc20_status.err_code = BC20_OK;
    uart7_printf("BC20 Init Done!\r\n");
    uart7_printf("====================================\r\n");
}


BC20_ErrorCode BC20_InitGPS(void)
{
    BC20_ErrorCode ret;

    
    uart7_printf("Enable GNSS...\r\n");
    ret = BC20_SendAT("AT+QGNSSC=1\r\n", "", 5000);
    if (ret != BC20_OK)
    {
        uart7_printf("GNSS Enable Failed\r\n");
        return BC20_ERR_GPS;
    }
    BC20_ClearRecvBuf();

    
    uart7_printf("Check GPS status...\r\n");
    ret = BC20_SendAT("AT+QGNSSC?\r\n", "+QGNSSC: 1", 5000);
    if (ret != BC20_OK)
    {
        uart7_printf("GPS Not Active\r\n");
        return BC20_ERR_GPS;
    }
    BC20_ClearRecvBuf();

    return BC20_OK;
}


static BC20_ErrorCode BC20_ParseGPRMC(const char *rmc_str, GPS_Data *gps)
{
    char *token;
    static char rmc_copy[BC20_BUF_LEN];  
    strncpy(rmc_copy, rmc_str, BC20_BUF_LEN - 1);
    rmc_copy[BC20_BUF_LEN - 1] = '\0';

    token = strtok(rmc_copy, ",");
    if (token == NULL) return BC20_ERR_GPS;

    token = strtok(NULL, ",");
    token = strtok(NULL, ",");
    if (token == NULL || strcmp(token, "A") != 0)
    {
        gps->is_valid = 0;
        uart7_printf("GPS Invalid (status=V)\r\n");
        return BC20_OK;
    }

    token = strtok(NULL, ",");
    if (token == NULL || strlen(token) < 5)
    {
        uart7_printf("Lat Invalid\r\n");
        return BC20_ERR_GPS;
    }
    float lat_deg = atof(token) / 100;
    int deg = (int)lat_deg;
    gps->latitude = deg + (lat_deg - deg) * 100 / 60;

    token = strtok(NULL, ",");
    if (token != NULL && strcmp(token, "S") == 0)
    {
        gps->latitude = -gps->latitude;
    }

    token = strtok(NULL, ",");
    if (token == NULL || strlen(token) < 6)
    {
        uart7_printf("Lon Invalid\r\n");
        return BC20_ERR_GPS;
    }
    float lon_deg = atof(token) / 100;
    deg = (int)lon_deg;
    gps->longitude = deg + (lon_deg - deg) * 100 / 60;

    token = strtok(NULL, ",");
    if (token != NULL && strcmp(token, "W") == 0)
    {
        gps->longitude = -gps->longitude;
    }

    gps->is_valid = 1;
    uart7_printf("GPS Valid: Lat=%.6f, Lon=%.6f\r\n", gps->latitude, gps->longitude);
    return BC20_OK;
}


BC20_ErrorCode BC20_GetGPSData(GPS_Data *gps)
{
    BC20_ErrorCode ret;
    char *rmc_ptr;
    char *end_ptr;

    if (gps == NULL)
    {
        return BC20_ERR_GPS;
    }

    memset(gps, 0, sizeof(GPS_Data));
    gps->is_valid = 0;

    uart7_printf("\r\nGet GPS Data...\r\n");
    
    ret = BC20_SendAT("AT+QGNSSRD=\"NMEA/RMC\"\r\n", "$GNRMC", 5000);
    if (ret != BC20_OK)
    {
        uart7_printf("GPS Read Timeout\r\n");
        BC20_ClearRecvBuf();
        return BC20_ERR_GPS;
    }

    
    rmc_ptr = strstr(s_recv_buf, "$GNRMC");
    if (rmc_ptr == NULL)
    {
        uart7_printf("No $GNRMC found\r\n");
        BC20_ClearRecvBuf();
        return BC20_ERR_GPS;
    }

    end_ptr = strchr(rmc_ptr, '\r');
    if (end_ptr != NULL)
    {
        *end_ptr = '\0';
    }
    uart7_printf("GNRMC: %s\r\n", rmc_ptr);

    ret = BC20_ParseGPRMC(rmc_ptr, gps);
    if (ret != BC20_OK)
    {
        gps->is_valid = 0;
    }

    BC20_ClearRecvBuf();
    return ret;
}


BC20_ErrorCode BC20_ConnectOneNet(void)
{
    BC20_ErrorCode ret;
    static char cmd[BC20_BUF_LEN];  

    uart7_send_string("Enter ConnectOneNet\r\n");
    uart7_printf("\r\n====================================\r\n");
    uart7_printf("Connect OneNet\r\n");

    
    uart7_printf("Disconnect old...\r\n");
    BC20_SendAT("AT+QMTDISC=0\r\n", "OK", 3000);
    BC20_SendAT("AT+QMTCLOSE=0\r\n", "OK", 3000);

   
    uart7_printf("Set MQTT 3.1.1\r\n");
    ret = BC20_SendAT("AT+QMTCFG=\"version\",0,4\r\n", "OK", 3000);
    if (ret != BC20_OK)
    {
        uart7_send_string("MQTT cfg FAIL\r\n");
        return BC20_ERR_OneNet;
    }

    
    uart7_printf("Open MQTT...\r\n");
    uart7_send_string("Open MQTT...\r\n");
    snprintf(cmd, BC20_BUF_LEN, "AT+QMTOPEN=0,\"%s\",1883\r\n", OneNet_SERVER);
    ret = BC20_SendAT(cmd, "+QMTOPEN: 0,0", 15000);
    if (ret != BC20_OK)
    {
        uart7_send_string("Open MQTT FAIL\r\n");
        return BC20_ERR_OneNet;
    }

    
    uart7_printf("Connect Device...\r\n");
    uart7_send_string("Login...\r\n");
    snprintf(cmd, BC20_BUF_LEN, "AT+QMTCONN=0,\"%s\",\"%s\",\"%s\"\r\n",
             OneNet_DEVICE_ID, OneNet_PRODUCT_ID, OneNet_TOKEN);
    ret = BC20_SendAT(cmd, "+QMTCONN: 0,0,0", 15000);
    if (ret != BC20_OK)
    {
        uart7_send_string("Login FAIL\r\n");
        return BC20_ERR_OneNet;
    }

    
    uart7_printf("Subscribe...\r\n");
    uart7_send_string("Subscribe...\r\n");
    snprintf(cmd, BC20_BUF_LEN, "AT+QMTSUB=0,1,\"$sys/%s/%s/thing/property/set\",2\r\n",
             OneNet_PRODUCT_ID, OneNet_DEVICE_ID);
    ret = BC20_SendAT(cmd, "+QMTSUB: 0,1,0,0", 5000);
    if (ret != BC20_OK)
    {
        uart7_send_string("Sub FAIL (ignore)\r\n");
    }

    s_bc20_status.is_connected = 1;
    uart7_printf("OneNet Connected!\r\n");
    uart7_printf("====================================\r\n");
    return BC20_OK;
}


BC20_ErrorCode BC20_SendToOneNet(const GPS_Data *gps, float temp, float humi, const HRSpO2_Data *hr_spo2, const char *incident)
{
    BC20_ErrorCode ret;
    static char cmd[BC20_BUF_LEN]; 
    static char json_buf[BC20_BUF_LEN];

    if (!s_bc20_status.is_connected)
    {
        uart7_printf("Not Connected!\r\n");
        return BC20_ERR_OneNet;
    }

    
    if (incident == NULL || incident[0] == '\0')
    {
        snprintf(json_buf, BC20_BUF_LEN,
                 "{\"id\":\"123\",\"version\":\"1.0\",\"params\":{"
                 "\"map\":{\"value\":{\"Lon\":\"%.6f\",\"Lat\":\"%.6f\"}},"
                 "\"Temp\":{\"value\":%.1f},"
                 "\"Humi\":{\"value\":%.1f},"
                 "\"HR\":{\"value\":%.1f},"
                 "\"SpO2\":{\"value\":%.1f}"
                 "}}",
                 gps->longitude, gps->latitude,
                 temp, humi,
                 hr_spo2 ? hr_spo2->heart_rate : 0.0f,
                 hr_spo2 ? hr_spo2->spo2 : 0.0f);
    }
    else
    {
        snprintf(json_buf, BC20_BUF_LEN,
                 "{\"id\":\"123\",\"version\":\"1.0\",\"params\":{"
                 "\"map\":{\"value\":{\"Lon\":\"%.6f\",\"Lat\":\"%.6f\"}},"
                 "\"Temp\":{\"value\":%.1f},"
                 "\"Humi\":{\"value\":%.1f},"
                 "\"HR\":{\"value\":%.1f},"
                 "\"SpO2\":{\"value\":%.1f},"
                 "\"incident\":{\"value\":\"%s\"}"
                 "}}",
                 gps->longitude, gps->latitude,
                 temp, humi,
                 hr_spo2 ? hr_spo2->heart_rate : 0.0f,
                 hr_spo2 ? hr_spo2->spo2 : 0.0f,
                 incident);
    }

    snprintf(cmd, BC20_BUF_LEN,
             "AT+QMTPUB=0,0,0,0,\"$sys/%s/%s/thing/property/post\",%s\r\n",
             OneNet_PRODUCT_ID, OneNet_DEVICE_ID, json_buf);

    uart7_printf("\r\nSend to OneNet: Temp=%.1f, Humi=%.1f, HR=%.1f, SpO2=%.1f",
                 temp, humi,
                 hr_spo2 ? hr_spo2->heart_rate : 0.0f,
                 hr_spo2 ? hr_spo2->spo2 : 0.0f);
    if (incident && incident[0])
    {
        uart7_printf(", Incident=%s", incident);
    }
    uart7_printf("\r\n");

    ret = BC20_SendAT(cmd, "OK", 5000);
    if (ret == BC20_OK)
    {
        uart7_printf("Send OK\r\n");
    }
    else
    {
        uart7_printf("Send FAIL\r\n");
    }
    BC20_ClearRecvBuf();
    return ret;
}

void BC20_ProcessReceivedData(void)
{
    uint8_t byte;
    static char recv_data[BC20_BUF_LEN];
    static uint16_t recv_idx = 0;

    while (uart3_read_data(&byte, 1) > 0)
    {
        if (recv_idx < BC20_BUF_LEN - 1)
        {
            recv_data[recv_idx++] = (char)byte;
            recv_data[recv_idx] = '\0';
        }

        if (byte == '\n' && recv_idx > 2)
        {
            if (strstr(recv_data, "+QMTRECV:") != NULL)
            {
                uart7_printf("\r\nDownlink: %s", recv_data);
            }
            recv_idx = 0;
            memset(recv_data, 0, BC20_BUF_LEN);
        }
    }
}