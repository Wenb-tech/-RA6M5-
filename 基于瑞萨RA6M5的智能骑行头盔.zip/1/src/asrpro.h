#ifndef ASRPRO_H
#define ASRPRO_H

#include <stdint.h>

typedef enum {
    ASR_CMD_NONE = 0,
    ASR_CMD_TEMP = 1,
    ASR_CMD_HUMI = 2,
    ASR_CMD_BOTH = 3,
    ASR_CMD_HELLO = 4,
    ASR_CMD_STOP_HELP = 5,
    ASR_CMD_LED_ON = 6,
    ASR_CMD_LED_OFF = 7,
    ASR_CMD_NEED_HELP = 8,
    ASR_CMD_NO_HELP = 9
} ASR_Cmd;

typedef struct {
    uint8_t is_ready;
    ASR_Cmd last_cmd;
} ASRPRO_Status;

extern ASRPRO_Status s_asr_status;

void asrpro_init(void);
void asrpro_process(void);
void asrpro_speak_temperature(float temp);
void asrpro_speak_humidity(float humi);
void asrpro_speak_both(float temp, float humi);
void asrpro_speak_hello(void);
void asrpro_speak_fall(void);

#endif