#include "eeprom_i2c.h"
#include "hal_data.h"

#define EEPROM_SCL_PIN    BSP_IO_PORT_02_PIN_06
#define EEPROM_SDA_PIN    BSP_IO_PORT_02_PIN_07
#define EEPROM_ADDR       0xA0

#define I2C_DELAY()       { for(volatile uint32_t i=0; i<1000; i++); }

static void i2c_scl_high(void);
static void i2c_scl_low(void);
static void i2c_sda_high(void);
static void i2c_sda_low(void);
static void i2c_sda_input(void);
static void i2c_sda_output(void);
static bsp_io_level_t i2c_sda_read(void);
static void i2c_start(void);
static void i2c_stop(void);
static bool i2c_write_byte(uint8_t data);
static uint8_t i2c_read_byte(bool ack);

static void i2c_scl_high(void)
{
    g_ioport.p_api->pinWrite(g_ioport.p_ctrl, EEPROM_SCL_PIN, BSP_IO_LEVEL_HIGH);
    I2C_DELAY();
}

static void i2c_scl_low(void)
{
    g_ioport.p_api->pinWrite(g_ioport.p_ctrl, EEPROM_SCL_PIN, BSP_IO_LEVEL_LOW);
    I2C_DELAY();
}

static void i2c_sda_high(void)
{
    g_ioport.p_api->pinWrite(g_ioport.p_ctrl, EEPROM_SDA_PIN, BSP_IO_LEVEL_HIGH);
    I2C_DELAY();
}

static void i2c_sda_low(void)
{
    g_ioport.p_api->pinWrite(g_ioport.p_ctrl, EEPROM_SDA_PIN, BSP_IO_LEVEL_LOW);
    I2C_DELAY();
}

static void i2c_sda_input(void)
{
    g_ioport.p_api->pinCfg(g_ioport.p_ctrl, EEPROM_SDA_PIN, IOPORT_CFG_PORT_DIRECTION_INPUT | IOPORT_CFG_PULLUP_ENABLE);
    I2C_DELAY();
}

static void i2c_sda_output(void)
{
    g_ioport.p_api->pinCfg(g_ioport.p_ctrl, EEPROM_SDA_PIN, IOPORT_CFG_PORT_DIRECTION_OUTPUT | IOPORT_CFG_PORT_OUTPUT_HIGH);
    I2C_DELAY();
}

static bsp_io_level_t i2c_sda_read(void)
{
    bsp_io_level_t level;
    g_ioport.p_api->pinRead(g_ioport.p_ctrl, EEPROM_SDA_PIN, &level);
    return level;
}

static void i2c_start(void)
{
    i2c_sda_output();
    i2c_sda_high();
    i2c_scl_high();
    i2c_sda_low();
    i2c_scl_low();
}

static void i2c_stop(void)
{
    i2c_sda_output();
    i2c_sda_low();
    i2c_scl_high();
    i2c_sda_high();
}

static bool i2c_write_byte(uint8_t data)
{
    i2c_sda_output();
    
    for (int i = 7; i >= 0; i--)
    {
        if (data & (1 << i))
        {
            i2c_sda_high();
        }
        else
        {
            i2c_sda_low();
        }
        i2c_scl_high();
        i2c_scl_low();
    }
    
    i2c_sda_input();
    i2c_scl_high();
    bool ack = (i2c_sda_read() == BSP_IO_LEVEL_LOW);
    i2c_scl_low();
    i2c_sda_output();
    
    return ack;
}

static uint8_t i2c_read_byte(bool ack)
{
    uint8_t data = 0;
    i2c_sda_input();
    
    for (int i = 7; i >= 0; i--)
    {
        i2c_scl_high();
        if (i2c_sda_read() == BSP_IO_LEVEL_HIGH)
        {
            data |= (1 << i);
        }
        i2c_scl_low();
    }
    
    i2c_sda_output();
    if (ack)
    {
        i2c_sda_low();
    }
    else
    {
        i2c_sda_high();
    }
    i2c_scl_high();
    i2c_scl_low();
    i2c_sda_high();
    
    return data;
}

void eeprom_i2c_init(void)
{
    g_ioport.p_api->pinCfg(g_ioport.p_ctrl, EEPROM_SCL_PIN, IOPORT_CFG_PORT_DIRECTION_OUTPUT | IOPORT_CFG_PORT_OUTPUT_HIGH);
    g_ioport.p_api->pinCfg(g_ioport.p_ctrl, EEPROM_SDA_PIN, IOPORT_CFG_PORT_DIRECTION_OUTPUT | IOPORT_CFG_PORT_OUTPUT_HIGH);
}

bool eeprom_write_byte(uint8_t addr, uint8_t data)
{
    i2c_start();
    if (!i2c_write_byte(EEPROM_ADDR))
    {
        i2c_stop();
        return false;
    }
    if (!i2c_write_byte(addr))
    {
        i2c_stop();
        return false;
    }
    if (!i2c_write_byte(data))
    {
        i2c_stop();
        return false;
    }
    i2c_stop();

    for (volatile uint32_t i = 0; i < 2000000; i++);
    return true;
}

bool eeprom_read_byte(uint8_t addr, uint8_t *data)
{
    i2c_start();
    if (!i2c_write_byte(EEPROM_ADDR))
    {
        i2c_stop();
        return false;
    }
    if (!i2c_write_byte(addr))
    {
        i2c_stop();
        return false;
    }
    
    i2c_start();
    if (!i2c_write_byte(EEPROM_ADDR | 0x01))
    {
        i2c_stop();
        return false;
    }
    
    *data = i2c_read_byte(false);
    i2c_stop();
    
    return true;
}

bool eeprom_write_bytes(uint8_t addr, uint8_t *data, uint16_t len)
{
    i2c_start();
    if (!i2c_write_byte(EEPROM_ADDR))
    {
        i2c_stop();
        return false;
    }
    if (!i2c_write_byte(addr))
    {
        i2c_stop();
        return false;
    }
    
    for (uint16_t i = 0; i < len; i++)
    {
        if (!i2c_write_byte(data[i]))
        {
            i2c_stop();
            return false;
        }
    }
    i2c_stop();
    
    for (volatile uint32_t i = 0; i < 500000; i++);
    return true;
}

bool eeprom_read_bytes(uint8_t addr, uint8_t *data, uint16_t len)
{
    i2c_start();
    if (!i2c_write_byte(EEPROM_ADDR))
    {
        i2c_stop();
        return false;
    }
    if (!i2c_write_byte(addr))
    {
        i2c_stop();
        return false;
    }
    
    i2c_start();
    if (!i2c_write_byte(EEPROM_ADDR | 0x01))
    {
        i2c_stop();
        return false;
    }
    
    for (uint16_t i = 0; i < len - 1; i++)
    {
        data[i] = i2c_read_byte(true);
    }
    data[len - 1] = i2c_read_byte(false);
    
    i2c_stop();
    return true;
}

void eeprom_erase_page(uint8_t page_addr, uint8_t page_size)
{
    uint8_t zero = 0x00;
    for (uint8_t i = 0; i < page_size; i++)
    {
        eeprom_write_byte(page_addr + i, zero);
    }
}
