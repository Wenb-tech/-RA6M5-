#ifndef OLED_SSD1306_H
#define OLED_SSD1306_H

#include <stdint.h>

#define OLED_I2C_ADDR       0x3C

#define OLED_SCL_PIN        BSP_IO_PORT_04_PIN_15
#define OLED_SDA_PIN        BSP_IO_PORT_04_PIN_14

#define OLED_WIDTH          128
#define OLED_HEIGHT         64

void oled_init(void);
void oled_clear(void);
void oled_show_char(uint8_t x, uint8_t y, char chr);
void oled_show_string(uint8_t x, uint8_t y, const char *str);
void oled_show_num(uint8_t x, uint8_t y, uint32_t num, uint8_t len);

#endif
