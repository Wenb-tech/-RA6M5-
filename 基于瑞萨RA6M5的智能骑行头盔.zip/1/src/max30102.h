#ifndef MAX30102_H
#define MAX30102_H

#include <stdint.h>

#define MAX30102_ADDR        0x57

#define MAX30102_REG_INT_STATUS1      0x00
#define MAX30102_REG_INT_STATUS2      0x01
#define MAX30102_REG_INT_ENABLE1      0x02
#define MAX30102_REG_INT_ENABLE2      0x03
#define MAX30102_REG_FIFO_WR_PTR      0x04
#define MAX30102_REG_OVF_COUNTER      0x05
#define MAX30102_REG_FIFO_RD_PTR      0x06
#define MAX30102_REG_FIFO_DATA        0x07
#define MAX30102_REG_FIFO_CONFIG      0x08
#define MAX30102_REG_MODE_CONFIG      0x09
#define MAX30102_REG_PARTICLE_CONFIG  0x0A
#define MAX30102_REG_LED1_PA          0x0C
#define MAX30102_REG_LED2_PA          0x0D
#define MAX30102_REG_PILOT_PA         0x10
#define MAX30102_REG_MULTI_LED_CTRL1  0x11
#define MAX30102_REG_MULTI_LED_CTRL2  0x12
#define MAX30102_REG_TEMP_INTR        0x1F
#define MAX30102_REG_TEMP_FRAC        0x20
#define MAX30102_REG_DIE_TEMP_CONFIG  0x21
#define MAX30102_REG_PROX_INT_THRESH  0x30
#define MAX30102_REG_REV_ID           0xFE
#define MAX30102_REG_PART_ID          0xFF

#define MAX30102_FIFO_DEPTH           32
#define MAX30102_SAMPLE_COUNT         100

typedef struct {
    int32_t heart_rate;
    int32_t spo2;
    int32_t ir_ac;
    int32_t red_ac;
    int32_t ir_dc;
    int32_t red_dc;
    uint8_t is_valid;
} MAX30102_Data;

void max30102_init(void);
uint8_t max30102_read_reg(uint8_t reg);
void max30102_write_reg(uint8_t reg, uint8_t value);
void max30102_read_fifo(uint32_t *ir, uint32_t *red);
void max30102_update(MAX30102_Data *data);
void max30102_reset(void);

#endif
