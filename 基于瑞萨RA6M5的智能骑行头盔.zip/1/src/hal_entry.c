#include "hal_data.h"
#include "uart_drv.h"
#include "bc20.h"
#include "max30102.h"
#include "dht11.h"
#include "mpu6050.h"
#include "asrpro.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

#if (1 == BSP_MULTICORE_PROJECT) && BSP_TZ_SECURE_BUILD
bsp_ipc_semaphore_handle_t g_core_start_semaphore =
{
    .semaphore_num = 0
};
#endif



static void delay_ms(uint32_t ms)
{
    for (volatile uint32_t i = 0; i < ms * 40000; i++);
}

static void delay_5s(void)
{
    for (uint32_t i = 0; i < 50; i++)
    {
        BC20_ProcessReceivedData();
        delay_ms(100);
    }
}

void hal_entry(void)
{
    fsp_err_t err;

    err = g_ioport.p_api->open(g_ioport.p_ctrl, g_ioport.p_cfg);
    if (FSP_SUCCESS != err)
    {
        while(1);
    }

    
    R_BSP_PinAccessEnable();
    R_BSP_PinCfg(BSP_IO_PORT_03_PIN_02, BSP_IO_DIRECTION_OUTPUT);
    R_BSP_PinWrite(BSP_IO_PORT_03_PIN_02, BSP_IO_LEVEL_LOW);
    R_BSP_PinAccessDisable();
    uart7_send_string("LED Init OK (P302, OFF)\r\n");

   


    
    uart3_init();

    
    uart7_init();

    
    uart7_send_string("UART7 Test OK!\r\n");
    uart7_printf("UART7 Test OK!\r\n");

   
    dht11_init();
    uart7_send_string("DHT11 Init OK\r\n");

    
    mpu6050_init();
    uart7_send_string("MPU6050 Init OK\r\n");

    
    asrpro_init();
    uart7_send_string("ASRPRO Init OK\r\n");

    /* 心率血氧数据（static 保持状态跨循环） */
    static MAX30102_Data max_data;
    static HRSpO2_Data hr_spo2_data;
    static uint32_t hr_spo2_update_tick = 0;
    static uint32_t system_tick = 0;

    /* 摔倒事件状态 */
    static char incident_str[32] = {0};
    static uint8_t fall_active = 0;

    /* 初始化 MAX30102 心率血氧传感器 */
    max30102_init();
    uart7_send_string("MAX30102 Init OK\r\n");

    
    {
        MAX30102_Data max_init;
        max30102_update(&max_init);
        if (max_init.is_valid)
        {
            hr_spo2_data.heart_rate = (float)max_init.heart_rate;
            hr_spo2_data.spo2 = (float)max_init.spo2;
            hr_spo2_data.is_valid = 1;
            uart7_printf("HR=%.1f, SpO2=%.1f\r\n",
                         hr_spo2_data.heart_rate, hr_spo2_data.spo2);
        }
    }

    
    uart7_send_string("Init BC20...\r\n");
    BC20_Init();

    {
        char dbg[64];
        snprintf(dbg, sizeof(dbg), "BC20 err=%d\r\n", s_bc20_status.err_code);
        uart7_send_data((uint8_t *)dbg, (uint16_t)strlen(dbg));
    }

    if (s_bc20_status.err_code == BC20_OK)
    {
        uart7_send_string("Connect OneNet...\r\n");
        BC20_ConnectOneNet();

        if (s_bc20_status.is_connected)
        {
            uart7_send_string("OneNet OK\r\n");
        }
        else
        {
            uart7_send_string("OneNet FAIL\r\n");
        }
    }
    else
    {
        uart7_send_string("BC20 Init FAIL\r\n");
    }

    uart7_send_string("Start\r\n");
    uart7_printf("\r\nASRPRO + DHT11 + MAX30102 Test Start!\r\n");

    while(1)
    {
        BC20_ProcessReceivedData();

        
        system_tick++;

       
        if (system_tick - hr_spo2_update_tick >= 20)
        {
            hr_spo2_update_tick = system_tick;
            max30102_update(&max_data);
            if (max_data.is_valid)
            {
                hr_spo2_data.heart_rate = (float)max_data.heart_rate;
                hr_spo2_data.spo2 = (float)max_data.spo2;
                hr_spo2_data.is_valid = 1;
                uart7_printf("HR=%.1f bpm, SpO2=%.1f %%\r\n",
                             hr_spo2_data.heart_rate, hr_spo2_data.spo2);
            }
            else
            {
                hr_spo2_data.is_valid = 0;
                uart7_send_string("MAX30102 data invalid\r\n");
            }
        }

        
        static DHT11_Data dht;
        float temp_val = 0.0f;
        float humi_val = 0.0f;
        uint8_t dht_ok = 0;
        int dht_ret = dht11_read(&dht);

        if (dht_ret == 0 && dht.is_valid)
        {
            temp_val = dht.temp_int + dht.temp_dec * 0.1f;
            humi_val = dht.humidity_int + dht.humidity_dec * 0.1f;
            dht_ok = 1;
            uart7_printf("Temp:%.1f C, Humi:%.1f %%\r\n", temp_val, humi_val);
        }
        else
        {
            uart7_send_string("DHT11 fail\r\n");
        }

        
        asrpro_process();
        if (s_asr_status.last_cmd != ASR_CMD_NONE)
        {
            switch (s_asr_status.last_cmd)
            {
                case ASR_CMD_TEMP:
                    if (dht_ok)
                        asrpro_speak_temperature(temp_val);
                    else
                        uart7_send_string("DHT11 fail, skip speak\r\n");
                    break;
                case ASR_CMD_HUMI:
                    if (dht_ok)
                        asrpro_speak_humidity(humi_val);
                    else
                        uart7_send_string("DHT11 fail, skip speak\r\n");
                    break;
                case ASR_CMD_BOTH:
                    if (dht_ok)
                        asrpro_speak_both(temp_val, humi_val);
                    else
                        uart7_send_string("DHT11 fail, skip speak\r\n");
                    break;
                case ASR_CMD_HELLO:
                    asrpro_speak_hello();
                    break;
                case ASR_CMD_LED_ON:
                    R_BSP_PinAccessEnable();
                    R_BSP_PinWrite(BSP_IO_PORT_03_PIN_02, BSP_IO_LEVEL_HIGH);
                    R_BSP_PinAccessDisable();
                    uart7_send_string("LED ON\r\n");
                    break;
                case ASR_CMD_LED_OFF:
                    R_BSP_PinAccessEnable();
                    R_BSP_PinWrite(BSP_IO_PORT_03_PIN_02, BSP_IO_LEVEL_LOW);
                    R_BSP_PinAccessDisable();
                    uart7_send_string("LED OFF\r\n");
                    break;
              
                default:
                    break;
            }
            s_asr_status.last_cmd = ASR_CMD_NONE;
        }

        
        static MPU6050_Data mpu;
        int mpu_ret = mpu6050_read_accel(&mpu);
        if (mpu_ret == 0 && mpu.is_valid)
        {
            uart7_printf("MPU6050: AX=%.2fg, AY=%.2fg, AZ=%.2fg\r\n", mpu.ax_g, mpu.ay_g, mpu.az_g);

            
            static uint32_t fall_count = 0;
            static uint8_t fall_triggered = 0;

            if (mpu.az_g > -0.3f && fall_triggered == 0)
            {
                fall_triggered = 1;
                fall_active = 1;
                fall_count++;
                
                static const uint8_t incident_no_help_utf8[] = {0xE4, 0xB8, 0x85, 0xE6, 0x93, 0xA6, 0xE5, 0x80, 0x9A, 0x00};
                snprintf(incident_str, sizeof(incident_str), "%s", (char *)incident_no_help_utf8);
                uart7_printf("Fall DETECTED! AZ=%.2fg, count=%d\r\n", mpu.az_g, fall_count);
                asrpro_speak_fall();
            }
            else if (mpu.az_g < -0.7f && fall_triggered == 1)
            {
                fall_triggered = 0;
                fall_active = 0;
                memset(incident_str, 0, sizeof(incident_str));
                uart7_printf("Fall recovered, AZ=%.2fg\r\n", mpu.az_g);
            }
        }
        else
        {
            uart7_send_string("MPU6050 read fail\r\n");
        }

        
        if (s_bc20_status.is_connected)
        {
            static GPS_Data gps;
            memset(&gps, 0, sizeof(gps));

            uart7_send_string("GetGPS...\r\n");
            BC20_ErrorCode gps_ret = BC20_GetGPSData(&gps);

            uart7_printf("GPS ret=%d, valid=%d\r\n", gps_ret, gps.is_valid);

            if (gps.is_valid && dht_ok && hr_spo2_data.is_valid)
            {
                uart7_printf("Lat:%.6f, Lon:%.6f\r\n", gps.latitude, gps.longitude);

                BC20_SendToOneNet(&gps, temp_val, humi_val, &hr_spo2_data,
                                  incident_str[0] ? incident_str : NULL);
                uart7_send_string("Data sent\r\n");
            }
            else
            {
                uart7_send_string("Skip send (GPS or DHT11 or HR/SpO2 invalid)\r\n");
            }
        }
        else
        {
            uart7_send_string("BC20 not connected\r\n");
        }

        delay_ms(1000);
    }

#if BSP_TZ_SECURE_BUILD
    R_BSP_NonSecureEnter();
#endif
}

#if BSP_TZ_SECURE_BUILD

FSP_HEADER
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
FSP_FOOTER

#endif
