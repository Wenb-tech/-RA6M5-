./objects/bc20.o: src\bc20.c src\bc20.h src\uart_drv.h
